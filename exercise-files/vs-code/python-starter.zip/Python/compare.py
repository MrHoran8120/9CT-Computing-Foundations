# Open this file in Notepad or TextEdit, then in VS Code. What looks different?
name = input("What is your name? ")
year = 9

if year == 9:
    print("Welcome to Year 9, " + name + "!")
else:
    print("Hello, " + name + ".")

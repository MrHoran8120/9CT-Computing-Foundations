# This program has three mistakes. Fix them one at a time.
name = input("What is your name? ")
print("Hello, " + name

age = 14
if age > 12
    print("You are a teenager.")

print("Nice to meet you, " + nmae)

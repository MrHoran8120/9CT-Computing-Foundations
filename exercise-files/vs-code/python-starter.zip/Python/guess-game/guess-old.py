import random

secret = random.randint(1, 10)
guess = int(input("Guess my number between 1 and 10: "))
print("The number was " + str(secret) + ".")

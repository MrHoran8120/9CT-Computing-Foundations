import random

secret = random.randint(1, 10)
guess = 0

print("Guess my number between 1 and 10.")
while guess != secret
    guess = int(input("Your guess: "))
    if guess < secret:
        print("Too low.")
    elif guess > secret:
        pritn("Too high.")

print("You got it!")
